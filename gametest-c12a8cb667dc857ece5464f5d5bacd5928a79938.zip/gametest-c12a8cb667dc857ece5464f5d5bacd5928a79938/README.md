# TG Detective Bot (Test NPC Chat)

## Setup
1) `npm i`
2) Create `.env` based on `.env.example`
3) Put prompt .txt files into `./prompts`

## Run
`node index.mjs`

## Commands
- /start
- /list
- /npc <name>
- /stage <ilya|tatyana|alina> <0|1|2>
- /reset
- /state
